# CLAUDE.md — 机器人数据采集 & pi0.5 pipeline

## 项目概述
pi0.5 VLA 全链路：数据采集 → 模型微调 → 部署推理。
7-DoF 左臂 + LinkerHand 夹爪，通过 WebSocket 桥接 ROS2 Humble 远程控制机器。

## 硬件

| 设备 | 位置 | 说明 |
|------|------|------|
| spark-adaf (本机) | /home/arm | Docker 运行 pi0.5 推理/采集 |
| ROBOT_HOST (远程) | sunrise@... / sshpass -p 'sunrise' | 机械臂控制 + ROS2 + CAN |
| 机械臂 | 远程 | 7-DoF 左臂 (L1~L7) + 右臂 (R1~R7, 不用) |
| 夹爪 | 远程 | LinkerHand, 通过 /execute_hand_grasp 控制 |
| 正面相机 | 远程, USB3 | Orbbec Gemini 335L, namespace /camera |
| 夹爪相机 | 远程, USB2 | Orbbec Gemini 305, namespace /camera_wrist |
| CAN 总线 | 远程 | can0 + can1, 1Mbps, 两个都必须要 |

## 关键文件

### 本机 (/home/arm/ + /workspace/)
- `robot_client.py` — LeRobot Robot 协议的 WebSocket 客户端
- `pi05_workspace/collect_data.py` — 数据采集脚本
- `robot_server.py` — 同步到远程的桥接服务源码
- `data_collection_guide.md` — 完整启动流程文档

### 远程 (/home/sunrise/)
- `robot_server.py` — WebSocket + ROS2 CLI 桥接服务（实际运行）
- `ros2_ws/` — ROS2 工作空间 (grasp_bringup, arm_moveit, arm_hardware)
- `calibration_ws/` — 电机标定参数/关节限位
- `vision_ws/` — Orbbec 相机驱动

## 远程 IP 配置

所有代码通过 `ROBOT_HOST` 环境变量读取远程 IP，默认 `192.168.127.66`：
```bash
export ROBOT_HOST=192.168.127.66
```
也可直接传参 `--host` 或 `NetworkRobot("ip", 8765)`。

## 系统架构

```
本机 (Docker pi_dev)
  └── robot_client.py ──WebSocket──→ 远程 (\${ROBOT_HOST}:8765)
                                       ├── robot_server.py (CLI 桥接)
                                       ├── ros2_control_node (硬件控制)
                                       ├── ROS2 topics / services
                                       ├── Gemini 335L (/camera)
                                       └── Gemini 305 (/camera_wrist)
```

## 启动顺序（6 步）

```bash
# 远程: 0. 确认相机 USB 连接
lsusb | grep orbbec  # 应有 335L + 305

# 远程: 1. CAN 总线
sudo ip link set can0 down && sudo ip link set can0 type can bitrate 1000000 && sudo ip link set can0 up
sudo ip link set can1 down && sudo ip link set can1 type can bitrate 1000000 && sudo ip link set can1 up

# 远程: 2. 机械臂 + MoveIt
source /opt/ros/humble/setup.bash && source /home/sunrise/ros2_ws/install/setup.bash && source /home/sunrise/calibration_ws/install/setup.bash
ros2 launch arm_moveit demo.launch.py use_rviz:=false
# 等 30-40s 关节进入 MIT mode

# 远程: 3. 相机驱动 (两台)
source /opt/ros/humble/setup.bash && source /home/sunrise/vision_ws/install/setup.bash
ros2 launch orbbec_camera gemini_330_series.launch.py camera_name:=camera serial_number:=CP2G853000G1 enable_point_cloud:=false enable_depth:=true depth_width:=640 depth_height:=480 color_width:=640 color_height:=480 color_fps:=10 depth_fps:=10 &
ros2 launch orbbec_camera gemini305.launch.py camera_name:=camera_wrist enable_point_cloud:=false enable_depth:=false color_width:=640 color_height:=480 color_fps:=10

# 远程: 4. WebSocket 桥接
source /opt/ros/humble/setup.bash && source /home/sunrise/ros2_ws/install/setup.bash && source /home/sunrise/calibration_ws/install/setup.bash
python3 /home/sunrise/robot_server.py --port 8765

# 本机: 5. 采集
source /workspace/openpi/openpi/bin/activate
python3 /workspace/collect_data.py --host \$ROBOT_HOST --port 8765 --episodes 50 --episode-time 30 --fps 10 --task "pick up the red cube"
```

## WebSocket 协议

### 请求 (JSON 文本帧)
```json
{"type": "get_observation"}              # 读状态+图像
{"type": "send_action", "joint_positions": [...], "gripper": 0.0}  # 发动作
{"type": "hand_action", "command": "open|close"}
{"type": "get_info"}                     # 机器人信息
{"type": "stop"}                         # 紧急停止
```

### 响应
- `get_observation` → JSON 元数据帧（含 has_front_image / has_wrist_image）+ 两帧 JPEG 二进制
- `send_action` → JSON action_result
- 关节数据: 7 个 L1~L7 弧度值
- image: 640x480 RGB, JPEG 编码

### 动作/状态维度
- state_dim = 8 (L1_joint ~ L7_joint + gripper, 关节弧度, gripper 0~1)
- action_dim = 8 (7 关节 + 1 夹爪)
- gripper 状态无硬件反馈，由 client 根据上次发送的 command 追踪

### LinkerHand 灵巧手
- **二值控制**：0.0=张开, >0.0=闭合（无死区，只有全开/全关两个状态）
- SDK 接口：`finger_move(pose=[255]*6)` 张开，`finger_move(pose=[0]*6)` 闭合
- 6 个手指参数中只有第一个有效，其余未使用
- `get_state()` 返回 6 维数组 (0~255)，首值为当前手指位置
- `/execute_hand_grasp` 服务请求字段为 `grasp_type` + `arm_side`，非 `command`

## ROS2 服务接口

| 服务 | 类型 | 用途 |
|------|------|------|
| /execute_motion_step | grasp_bringup/srv/ExecuteMotionStep | 执行关节动作 (timeout ~20s) |
| /execute_hand_grasp | grasp_bringup/srv/ExecuteHandGrasp | 夹爪控制, 字段 "grasp_type" + "arm_side" |
| /stop_motion | grasp_bringup/srv/StopMotion | 停止运动 |

## 关键技术决策

### robot_server.py 缓存架构
- **服务调用**（send_action）使用 `ros2 service call` CLI 子进程，避免了 rclpy 长连接内存泄漏
- **状态/图像读取**（get_observation）使用 rclpy 后台缓存线程（`CameraCache`）：
  - 单线程 + SingleThreadedExecutor，订阅 `/camera/.../compressed`、`/joint_states`、`/hand_state`
  - 最新数据实时缓存，get_observation() 直接读取，零延迟
  - `hand_state` 由 `hand_grasp_server.py` 以 20Hz 发布 6 维 Int32MultiArray (0~255)
  - rclpy 订阅头几帧可能触发 FastDDS 刷屏报错，不影响功能
- 内存占用稳定 ~70MB（未触发 11GB 泄漏问题）

### 关节数据解析
- `joint_state_broadcaster` 发布 14 个关节（L1-L7 + R1-R7）
- robot_server.py 的 CameraCache 通过 rclpy JointState 订阅实时缓存前 7 个关节
- robot_client.py 取 `observation.state[0:7]` 作为关节角度

### OOM Killer
- rviz2 在无显示器环境触发 OOM → 连带杀掉 robot_state_publisher
- 必须加 `use_rviz:=false`
- 如果触发，pkill -f "ros2 launch" 全部重启

## 相机采集
- robot_server.py 使用 rclpy CameraCache 后台线程 + compressed topic 订阅
- 一个 background thread 订阅两个 compressed topic，缓存最新 JPEG
- get_observation() 直接从缓存读取，避免每帧 subprocess 开销
- 机械臂关关节动时 rclpy 的 FastDDS 错误会刷屏，不影响功能
- 如果 image_raw/compressed topic 不可用（如启动初期），返回空白图像

## 代码现状 — TODO

### 已知问题：双相机串号冲突
- 两台 Orbbec 相机同时接在同一个 USB hub 上时，不指定 serial_number 会拿错设备
- 335L 必须加 `serial_number:=CP2G853000G1` 启动
- 305 不需要（系统只有一台 305）

### teleop_step() action 占位
- 当前 dummy_action 复制当前关节位置 + 0 gripper
- 接入 VR 数据后替换

## SSH
```bash
export ROBOT_HOST=192.168.127.66
sshpass -p 'sunrise' ssh -o StrictHostKeyChecking=no "sunrise@\$ROBOT_HOST"
sshpass -p 'sunrise' scp -o StrictHostKeyChecking=no <local> "sunrise@\$ROBOT_HOST":<remote>
```

## 常见问题排查
1. **L1 关节初始化失败** → can1 没配或 calibration_ws 没 source
2. **OOM killer** → rviz2 没加 use_rviz:=false
3. **topic 没数据** → 检查 USB 连接 `lsusb | grep orbbec`
4. **send_action 超时** → 机械臂忙或轨迹规划失败，~20s 阈值
5. **robot_server 崩溃** → 检查 8765 端口占用，看 stdout
6. **内存泄漏** → 别用 rclpy 长连接订阅
7. **没有 /dev/video*** → 重新插拔 USB，或重启 camera driver
