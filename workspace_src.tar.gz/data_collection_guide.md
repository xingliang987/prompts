# 数据采集流程指南

## 远程 IP 配置

设置环境变量 `ROBOT_HOST` 指定远程机器 IP：
```bash
export ROBOT_HOST=192.168.127.66
```
代码和脚本中默认使用此变量，无需在每个命令中手动指定 IP。

## 系统架构

```
本机 (spark-adaf, Docker pi_dev)
  └── robot_client.py ──WebSocket──→ 远程 (ROBOT_HOST)
                                       ├── robot_server.py (CLI 桥接)
                                       ├── ros2_control_node (硬件控制)
                                       ├── ROS2 topics / services
                                       ├── Gemini 335L (正前方, /camera)
                                       └── Gemini 305 (夹爪, /camera_wrist)
```

---

## 启动流程（按顺序）

### 远程机器 ROBOT_HOST

**0. 相机 USB**
```bash
# 确认两台 Orbbec 相机都被 USB 检测到
lsusb | grep -i orbbec
# 应该看到:
#   Bus 002 Device ...: ID 2bc5:0804 Orbbec Gemini 335L   (正面)
#   Bus 001 Device ...: ID 2bc5:0840 Orbbec Gemini 305     (夹爪)
```
- 相机需要在启动驱动**之前**插好 USB
- 335L 接 USB3.0 口（Bus 002），305 接 USB2.0 口（Bus 001）
- 如果没检测到，检查物理连接

**1. CAN 总线**
```bash
sudo ip link set can0 down
sudo ip link set can0 type can bitrate 1000000
sudo ip link set can0 up

sudo ip link set can1 down
sudo ip link set can1 type can bitrate 1000000
sudo ip link set can1 up
```
两个 CAN 都需要（can0 + can1），只配 can0 会导致 L1 关节初始化失败。

**2. 机械臂硬件 + MoveIt**
```bash
source /opt/ros/humble/setup.bash
source /home/sunrise/ros2_ws/install/setup.bash
source /home/sunrise/calibration_ws/install/setup.bash

ros2 launch arm_moveit demo.launch.py use_rviz:=false
```
- `use_rviz:=false` **必须加**，否则 rviz2 在无屏环境下会吃满内存触发 OOM killer
- 必须 source `calibration_ws`，否则关节初始化可能失败
- 等待 30-40 秒，所有 7 个关节会依次进入 MIT mode
- 确认 joint_states 有数据：`ros2 topic echo /joint_states --once --field position`

**3. 相机驱动（两台）**
```bash
source /opt/ros/humble/setup.bash
source /home/sunrise/vision_ws/install/setup.bash

# 正面 Gemini 335L（必须指定 serial_number，否则会拿错相机）
ros2 launch orbbec_camera gemini_330_series.launch.py \
  camera_name:=camera \
  serial_number:=CP2G853000G1 \
  enable_point_cloud:=false \
  enable_depth:=true \
  depth_width:=640 depth_height:=480 \
  color_width:=640 color_height:=480 \
  color_fps:=10 depth_fps:=10 &

# 夹爪 Gemini 305（用不同 namespace）
ros2 launch orbbec_camera gemini305.launch.py \
  camera_name:=camera_wrist \
  enable_point_cloud:=false \
  enable_depth:=false \
  color_width:=640 color_height:=480 \
  color_fps:=10
```
- 确认 topic：`ros2 topic list | grep -E "camera/"` 应有 `/camera/` 和 `/camera_wrist/` 两组
- 335L: 彩色 640x480 @ 10fps MJPG + 深度 640x480 @ 10fps Y16
- 305: 彩色 640x480 @ 10fps MJPG，USB2.1 连接，无深度
- 如果 topic 没出现，先 `lsusb | grep orbbec` 确认 USB 检测到设备

**4. WebSocket 桥接服务**
```bash
source /opt/ros/humble/setup.bash
source /home/sunrise/ros2_ws/install/setup.bash
source /home/sunrise/calibration_ws/install/setup.bash

python3 /home/sunrise/robot_server.py --port 8765
```
- 使用 ROS2 CLI 工具而非 rclpy，避免 FastDDS 序列化错误导致的内存泄漏
- 启动后检查端口：`ss -tlnp | grep 8765`
- 内存占用量约 70MB

### 本机 Docker (pi_dev)

**5. 验证连接**
```bash
source /workspace/openpi/openpi/bin/activate
PYTHONPATH=/workspace:$PYTHONPATH python3 -c "
from robot_client import NetworkRobot
robot = NetworkRobot('ROBOT_HOST', 8765)
robot.connect()
obs = robot.capture_observation()
print('关节:', obs['observation.state'])
print('图像:', obs['observation.images.front'].shape)
robot.disconnect()
"
```

**6. 数据采集**
```bash
source /workspace/openpi/openpi/bin/activate
python3 /workspace/collect_data.py \
  --host ROBOT_HOST --port 8765 \
  --episodes 50 --episode-time 30 \
  --fps 10 --task "pick up the red cube"
```

---

## 文件清单

### 本机 /home/arm/

| 文件 | 作用 |
|------|------|
| `robot_client.py` | LeRobot Robot 网络 wrapper，实现 `teleop_step()` / `capture_observation()` / `send_action()` |
| `collect_data.py` | 数据采集脚本 |
| `robot_server.py` | 已同步到远程 `/home/sunrise/robot_server.py` |

### 远程 ROBOT_HOST

| 文件 | 作用 |
|------|------|
| `/home/sunrise/robot_server.py` | WebSocket + ROS2 CLI 桥接服务 |
| `/home/sunrise/ros2_ws/` | ROS2 工作空间（grasp_bringup, arm_moveit, arm_hardware） |
| `/home/sunrise/calibration_ws/` | 标定参数工作空间 |
| `/home/sunrise/vision_ws/` | Orbbec 相机驱动（gemini_330_series.launch.py） |
| `/home/sunrise/Desktop/testing/launch_rviz_demo.sh` | 原始启动脚本（含 CAN 配置，不要直接用它，参考上面的步骤） |

### 相机规格

| 参数 | 正面 Gemini 335L | 夹爪 Gemini 305 |
|------|------------------|-----------------|
| USB | 3.2 SuperSpeed | 2.1 |
| 串号 | CP2G853000G1 | — |
| 固件 | 1.4.60 / SDK 2.7.6 | — |
| 彩色 | 640x480 @ 10fps, MJPG, rgb8 | 640x480 @ 10fps, MJPG |
| 深度 | 640x480 @ 10fps, Y16 | 不支持 |
| ROS2 Namespace | `/camera` | `/camera_wrist` |
| 关键 Topic | `/camera/color/image_raw/compressed` | `/camera_wrist/color/image_raw/compressed` |

---

## 注意事项

### OOM Killer
- rviz2 在无显示器环境下会占用大量内存并触发 OOM killer，连带杀掉 `robot_state_publisher` 和其他节点
- 启动时必须加 `use_rviz:=false`
- 如果已经触发 OOM，需要 `pkill -f "ros2 launch"` 全部杀掉后重新启动

### FastDDS 序列化错误
- 终端会不断刷 `Fast CDR exception deserializing message` 的错误
- 这是 FastDDS 在多接口/多进程环境下的已知问题，不影响 ROS2 通讯功能

### 关节数据 & gripper 状态
- `joint_state_broadcaster` 发布所有 14 个关节（L1-L7 + R1-R7）
- `robot_client.py` 只取前 7 个（L1_joint ~ L7_joint），加 1 个 gripper 状态
- 关节位置为弧度值
- **observation.state 维度 = 8**（7 关节 + gripper），**action 维度 = 8**（7 关节 + gripper）
- 关节数据通过 rclpy JointState 订阅实时缓存，零延迟读取，不依赖每帧 ros2 CLI 子进程
- 灵巧手状态通过 `hand_grasp_server.py` 以 20Hz 发布到 `/hand_state` topic
- `robot_server.py` 的 CameraCache 订阅 `/hand_state`，在 observation metadata 中返回 `hand_state` 数组

### LinkerHand 灵巧手
- 灵巧手为 **二值控制**，只有全开 / 全关两个状态
  - `finger_move(pose=[0] * 6)` → 握拳（闭合）
  - `finger_move(pose=[255] * 6)` → 全开
  - 6 个手指参数中只有第一个有效，其余 5 个未使用
- 无中间位置反馈，`get_state()` 返回 `[20, 0, 0, 0, 0, 0]` 这样的 6 维数组（0~255），首值为当前手指位置
- gripper 阈值映射（`robot_server.py` / `robot_client.py` 一致）：
  - **0.0** → 张开
  - **> 0.0** → 闭合
  - 无死区（灵巧手只有开关，没有保持逻辑）
- 状态追踪方式：client 端根据上次发送的 command 记录 `_gripper_state`，无硬件反馈闭环

### ROS2 服务
| 服务 | 类型 | 用途 | 请求字段 | 注 |
|------|------|------|---------|----|
| `/execute_hand_grasp` | `ExecuteHandGrasp.srv` | 灵巧手控制 | `grasp_type` (open/close/grasp), `arm_side` | 非 `command` 字段 |
| `/execute_motion_step` | `ExecuteMotionStep.srv` | 关节动作 | `step_type`, `arm_side`, `joint_positions[7]`, ... | 超时阈值 ~20s |
| `/stop_motion` | `StopMotion.srv` | 紧急停止 | 无 | |

### 采集脚本
- 当前 `teleop_step()` 的 action 为占位值（复制了当前关节状态）
- 实际采集时需要接入 VR 数据替换 `dummy_action`
- 每帧调用 `teleop_step(record_data=True)`，不感知时序
- 一个 episode 是一条完整演示（~30 秒 / 300 帧 @ 10fps）

### 多 task 数据集管理
- **一次采集 = 一个数据集**，每个数据集只含一个 task（所有 episodes 共用同一个 `--task`）
- 换 task 就改 `--task` 重新跑一次，输出到不同目录：

  ```bash
  python3 /workspace/collect_data.py --task "pick up the red cube"  --episodes 50 --output data/pick_red_cube
  python3 /workspace/collect_data.py --task "place on tray"         --episodes 50 --output data/place_on_tray
  python3 /workspace/collect_data.py --task "push the button"       --episodes 50 --output data/push_button
  ```

- 训练时多个数据集组合加载，框架自动处理采样平衡：

  ```python
  from lerobot.common.datasets.lerobot_dataset import LeRobotDataset

  datasets = [
      LeRobotDataset("data/pick_red_cube", root="."),
      LeRobotDataset("data/place_on_tray", root="."),
      LeRobotDataset("data/push_button", root="."),
  ]
  ```

- 每个 frame 的 `task` 字段告诉模型当前该执行什么指令，所以不同 task 之间不能用同一个 prompt

### 服务调用超时
- `send_action()` 调用 `/execute_motion_step` 服务，可能超时（~20 秒阈值）
- 机械臂忙或轨迹规划失败时会返回错误
- 夹爪服务字段为 `command`，已在 server 端处理

### 相机
- 335L 初始化约 2 秒，305 约 3 秒
- 使用 compressed topic 获取 JPEG（`/camera/.../image_raw/compressed`）
- 如果 image_raw 不出数据，先 `lsusb | grep orbbec` 确认 USB 检测到设备
- 彩色帧率 10fps，和采集帧率一致（`--fps 10`）
- 夹爪相机 305 不支持深度，`enable_depth:=false`

### 双相机串号冲突
- 两台 Orbbec 同时接在同一 USB hub 时，不指定 serial_number 会拿错设备
- 335L 必须加 `serial_number:=CP2G853000G1`，305 不需要

### Web 监控界面
- `python3 /home/arm/web_monitor.py --robot-host ROBOT_HOST --web-port 8080`
- 浏览器打开 `http://localhost:8080` 即可查看关节角度和相机实时串流
- 浏览器通过 WebSocket 直连 robot_server，独立运行不依赖 Docker
- 关节数据通过 rclpy 后台缓存实时读取，无额外延迟

### 启动顺序总结
```
1. CAN 总线 (can0 + can1)
       ↓
2. 机械臂硬件 + MoveIt (use_rviz:=false, 等 30s)
       ↓
3. 相机驱动 (335L 正面 + 305 夹爪)
       ↓
4. WebSocket 桥接 (robot_server.py)
       ↓
5. 采集脚本 (collect_data.py)
```
